<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<title>Email Form</title>
</head>
<body>

<div class="container mt-5">
	<h2 class="mb-4">Send Email</h2>
	<form action="#" method="post">
		<div class="mb-3">
			<label for="recipient" class="form-label">Recipient Email</label>
			<input type="email" class="form-control" id="recipient" name="recipient" required>
		</div>
		<div class="mb-3">
			<label for="subject" class="form-label">Subject</label>
			<input type="text" class="form-control" id="subject" name="subject" required>
		</div>
		<div class="mb-3">
			<label for="message" class="form-label">Message</label>
			<textarea class="form-control" id="message" name="message" rows="4" required></textarea>
		</div>
		<button type="submit" class="btn btn-primary">Send Email</button>
	</form>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYbFExlZ9M" crossorigin="anonymous"></script>
</body>
</html>
