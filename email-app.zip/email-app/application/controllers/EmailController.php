<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class EmailController extends CI_Controller 
{

    public function __construct() 
	{
        parent::__construct();
        $this->load->library('email');
    }

    public function send_email() 
	{
        // Your email sending logic goes here

        $config = array(
            'protocol' => 'smtp',
            'smtp_host' => 'your_smtp_host',
            'smtp_port' => 587,
            'smtp_user' => 'your_smtp_user',
            'smtp_pass' => 'your_smtp_password',
            'mailtype' => 'html',
            'charset' => 'utf-8',
            'wordwrap' => TRUE
        );

        $this->email->initialize($config);

        $this->email->from('your@example.com', 'Your Name');
        $this->email->to('recipient@example.com');
        $this->email->subject('Email Test');
        $this->email->message('Testing the email class.');

        $this->email->send();

        echo $this->email->print_debugger();
    }
}
